import React from 'react';
import './App.css';
import { HeaderComponent } from './compenents/header/headerComponent'
import MainComponent from './compenents/main/mainComponent'

function App() {
  
  return (
    <div>
      <MainComponent title="Header"></MainComponent>
    </div>
  );
}

export default App;
